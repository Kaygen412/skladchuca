﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите ваше имя:");
            string name = Console.ReadLine();

            Console.WriteLine("Введите ваш город:");
            string city = Console.ReadLine();

            Console.WriteLine("Введите ваш возраст:");
            string age = Console.ReadLine();

            Console.WriteLine($"Ваше имя: {name}, Ваш город: {city}, и Ваш возраст: {age}");
        }
    }
}
