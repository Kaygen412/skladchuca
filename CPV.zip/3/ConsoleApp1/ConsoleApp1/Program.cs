﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите ваш возраст");
            int age = Convert.ToInt32(Console.ReadLine());

            if (age >= 0 && age <= 6 )
            {
                Console.WriteLine("Вы ребёнок");
            }

            else if (age >= 7 && age <= 17)
            {
                Console.WriteLine("Вы несовершеннолетний");
            }

            else if (age >= 18 && age <=64)
            {
                Console.WriteLine("Взрослый");
            }

            else 
            {
                Console.WriteLine("Вы пенсионер");
            }

        }
    }
}
