﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Первое число:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Второе число:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Сумма: {a + b}");
            Console.WriteLine($"Разность: {a - b}");
            Console.WriteLine($"Произведение: {a * b}");
            Console.WriteLine($"Частное:{a / b}");

        }
    }
}
