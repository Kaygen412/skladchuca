﻿using System;
using System.Collections.Generic;
class User
{
    public string Name { get; set; }
    public int Age { get; set; }
    public bool IsAdmin { get; set; }
}

class Program
{
    static void Main()
    {
        User user1 = new User { Name = "СигмаКурседка", Age = 25, IsAdmin = true };
        User user2 = new User { Name = "Ситлали", Age = 19, IsAdmin = false };
        User user3 = new User { Name = "Гоша", Age = 32, IsAdmin = false };
        

        List<User> users = new List<User> { user1, user2, user3 };

        Console.WriteLine("Список пользователей:");
        foreach (User user in users)
        {
            string role = user.IsAdmin ? "Администратор" : "Обычный пользователь";
            Console.WriteLine($"Имя: {user.Name}, Возраст: {user.Age}, Роль: {role}");
        }
    }
}
