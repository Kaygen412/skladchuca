﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Твое число");
            int numb = Convert.ToInt32(Console.ReadLine());

            int sum = 0;

            Console.WriteLine($"Все числа от 1 до {numb}");

            for (int i = 0; i <= numb; i++)
            {
                Console.WriteLine(i + " ");
                sum += i;
            }

            Console.WriteLine($"\n\n2. Только чётные числа от 1 до {numb} ");
            for (int i = 0;i <= numb; i++)
            {
                if (i%2 == 0 )
                {
                    Console.WriteLine(i + "");
                }
            }
            Console.WriteLine($"\n\n3. Сумма всех чисел от 1 до {numb}: {sum}");
 
        }
    }
}
